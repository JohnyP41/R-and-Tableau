library(shiny)
library(tidyverse)
library(plotly)
library("readxl")
library(dplyr)
library(data.table)
ui <- fluidPage(
  titlePanel("Projekt"),
  sidebarLayout(
    sidebarPanel(
      helpText("Dane pochodzą z 2019 roku.")
    ),
    
    mainPanel(
      plotlyOutput("p1"),
      plotlyOutput("p9"),
      p("1.Widać ,że więcej emigruje kobiet niż mężczyzn w 2019 roku."),
      plotlyOutput("p2"),
      p("2.Najwiecej kobiet emigruje z województwa Śląskiego (1074 kobiety) w 2019 roku."),
      plotlyOutput("p3"),
      p("3.Najwiecej mężczyzn emigruje z województwa Śląskiego jest to 998 mężczyzn w 2019 roku."),
      plotlyOutput("p4"),
      p("4.Ogółem wyemigrowało z Polski 10726 osób w 2019 roku."),
      plotlyOutput("p5"),
      p("5.Najwięcej osób emigruje z województwa Śląskiego (2072 osób) w 2019 roku."),
      plotlyOutput("p6"),
      p("6.Z województwa Śląskiego (1657 osób) w 2019 roku."),
      plotlyOutput("p7"),
      p("7.Z województwa Opolskiego (566 osób) w 2019 roku."),
      plotlyOutput("p8"),
      p("8.Z województwa Opolskiego 276 mężczyzn w 2019 roku.")
    )
  )
)

server <- function(input, output) {
  output$p1 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `mężczyźni ogółem`),fill="blue")+
      labs(x="województwa",y="mężczyzni ogółem")
    ggplotly(x)
    
  })
  
  output$p9 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    x=ggplot(data = data) + 
    geom_col(mapping = aes(x = `Województwa`, y = `kobiety ogółem`),fill="blue")+
    labs(x="województwa",y="kobiety ogółem")
  ggplotly(x)
  })
  output$p2 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `kobiety ogółem`),fill="blue")+
      labs(x="województwa",y="kobiety ogółem")
    ggplotly(x)
  })
  output$p3 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `mężczyźni ogółem`),fill="blue")+
      labs(x="województwa",y="mężczyźni ogółem")
    ggplotly(x)
  })
  output$p4 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    
   x=ggplot(data = data) + 
      geom_col(mapping = aes(x = "ogółem", y = 10726),fill="blue")+
      labs(x="Ogółem",y="wemigrowało")
    ggplotly(x)
  })
  output$p5 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `ogółem`),fill="blue")+
      labs(x="województwa",y="ogółem")
    ggplotly(x)
  })
  output$p6 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `miasta razem`),fill="blue")+
      labs(x="województwa",y="miasta ogółem")
    ggplotly(x)
  })
  output$p7 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    
     x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `wieś razem`),fill="blue")+
      labs(x="województwa",y="wieś ogółem")
     ggplotly(x)
  })
  output$p8 <- renderPlotly({
    data <- read_excel("pl_emi_2019_00_1z.xlsx",range = "A9:J26",na=" ")
    data=data[c(FALSE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE,TRUE), ]
    data=setnames(data, c("O G Ó Ł E M"="Województwa","10726"="ogółem","5313"="mężczyźni ogółem","5413"="kobiety ogółem","7517"="miasta razem","3703"="mężczyźni miasta","3814"="kobiety miasta","3209"="wieś razem","1610"="mężczyźni wieś","1599"="kobiety wieś"))  
    
    x=ggplot(data = data) + 
      geom_col(mapping = aes(x = `Województwa`, y = `mężczyźni wieś`),fill="blue")+
      labs(x="województwa",y="mężczyźni wieś")
    ggplotly(x)
  })
  
}

shinyApp(ui = ui, server = server)